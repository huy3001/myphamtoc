<?php

class A_NextGen_RoyalSlider extends Mixin
{
	
}